
export interface PendingApproval {
    TaskName: string;
    TaskCount: number;
}

export interface Draft {
    TaskName: string;
    TaskCount: number;
}

export interface Unapproved {
    TaskName: string;
    TaskCount: number;
}

export interface Mytask {
    PendingApprovals: PendingApproval[];
    Drafts: Draft[];
    Unapproved: Unapproved[];
}

export interface AwaitingApproval {
    TaskCount: number;
    UserId: number;
    UserName: string;
}

export interface Reminders {
    AwaitingApprovals: AwaitingApproval[];
}

export interface MytaskRemainder {
    Mytask: Mytask;
    Reminders: Reminders;
}












