export  interface  EntityTypeHead  {
    id:  number;
    item:  string;
    type: string;
} 
