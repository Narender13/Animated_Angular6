import { Component, OnInit } from '@angular/core';
import { SearchService } from '../finance/search/service/search.service';
import { Router } from '@angular/router';
import { HomeService } from './services/home.service';
import { Activity } from './modal/activity';
import { CategoryType } from '../finance/search/model/category';
import { MytaskRemainder, Unapproved, Draft, PendingApproval, AwaitingApproval } from 'src/app/home/modal/mytaskremainder';


@Component({
  selector: 'rsa-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  userdata: any = { 'welcomeMsg': 'HELLO!','msg1': 'what do you want to do', 'msg2': 'today?' };
  categorydata: any;
  activityData: Activity[];
  category: number;
  categoryItem: string;
  searchval = '';
  entitysearchlist;
  pendingApprovals: PendingApproval[] = [];
  drafts: Draft[] = [];
  unApproved: Unapproved[] = [];
  awaitingApproval: AwaitingApproval[] = [];
  invalidsearch = true;
  opentasks: number;
  username:string;
  constructor(private searchService: SearchService, private homeservice: HomeService, private router: Router) { }

  ngOnInit() {
    this.getCategorydataData();
    this.getActivity();
    this.getEntitySearchListData();
    this.getMyTaskAndRemainder();
    this.getUserData()
  }

  getCategorydataData(): void {
    this.homeservice.getCategoryData().subscribe((dropDowndata) => {
      this.categorydata = dropDowndata;
    });
  }

  getEntitySearchListData(): void {
    this.homeservice.getEntityData().subscribe((searchlistdata) => {
      this.entitysearchlist = searchlistdata;
    });
  }

  displayCheckedItem(activity: Activity) {
    this.activityData.forEach(item => {
      if (item.item === activity.item) {
        item.checked = activity.checked;
      }
    });
  }

  getActivity(): void {
    this.homeservice.populateDropDown().subscribe((data) => {
      this.activityData = data;
    });
  }

  getMyTaskAndRemainder(): void {
    this.homeservice.getMyTaskRemainder().subscribe((mytaskremainder: MytaskRemainder) => {
      this.pendingApprovals = mytaskremainder.Mytask.PendingApprovals;
      this.drafts = mytaskremainder.Mytask.Drafts;
      this.unApproved = mytaskremainder.Mytask.Unapproved;
      this.awaitingApproval = mytaskremainder.Reminders.AwaitingApprovals;
    });
  }

  setCategory(category: CategoryType) {
    this.category = category.id;
    this.categoryItem = category.item;
    this.searchval = '';
  }

  search() {
    this.invalidsearch = (this.category !== undefined && this.category > 0) &&
      (this.searchval !== undefined && this.searchval !== '' && this.searchval.length > 0);
    if (this.invalidsearch) {
      this.router.navigate(['home/search/result'], {
        queryParams: {
          'inputData': this.searchval,
          'category': this.category,
          'categoryitem': this.categoryItem
        }
      });
    }

  }
  opentasksList(ev: number) {
    this.opentasks = (this.opentasks === ev) ? -1 : ev;
  }
  getUserData(): void {
    this.homeservice.getUserInfo().subscribe((data) => {
      this.username = data.firstname+" "+data.lastname;      
    });
   
  }
}
