import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-general',
  templateUrl: './general.component.html',
  styleUrls: ['./general.component.scss']
})
export class GeneralComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
