import { Injectable } from '@angular/core';
import { HttpParams, HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { map, catchError, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

import { handleErrorObservable } from '../../shared/utilites/helper';
import { RSAENDPOINTConstants } from '../../core/constants/rsa.api.end.points';
import { EntiteType } from '../model/entite-type';

@Injectable({
  providedIn: 'root'
})
export class EntiteCreateService {
  constructor(private http: HttpClient) { }

  getEntitieType(): Observable<EntiteType[]> {
    return this.http.get<EntiteType[]>(RSAENDPOINTConstants.ENTITEAPI).pipe(
      map(res => res),
      catchError(handleErrorObservable));
  }



}
