import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-debitnotes',
  templateUrl: './debitnotes.component.html',
  styleUrls: ['./debitnotes.component.scss']
})
export class DebitnotesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
