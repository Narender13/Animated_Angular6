import { Component, OnInit } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { CreatePaymentService } from './service/create-payment.service';
@Component({
  selector: 'rsa-create-payment',
  templateUrl: './create-payment.component.html',
  styleUrls: ['./create-payment.component.scss']
})
export class CreatePaymentComponent implements OnInit {
  title = 'Payment';
  level: any = 1;
  amount = 0;
  currency = 'AED';
  collapsetoheader: boolean;
  paymentForm: FormGroup;
  masterdata: any;
  BankName: any;
  results: any;
  errorMsg;
  terminals;
  pjctindicator;
  department;
  glaccount;
  slided;
  totallingacc;
  returnValue;
  constructor(public bsModalRef: BsModalRef, private fb: FormBuilder, private createPaymentService: CreatePaymentService) { }


  ngOnInit() {
    this.getAllMasterData();
    this.createPaymentForm();
    this.getSearchResultsC();
  }

  getSearchResultsC(): void {
    const params = { 'category': 3, 'searchkey': 110 };
    this.createPaymentService.getSearchResults(params).subscribe(
      dataReturn => {
        this.results = dataReturn;
        
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }


  getAllMasterData(): void {
    this.createPaymentService.getAllMasterData().subscribe(
      dataReturn => {
        this.masterdata = dataReturn;
        
        this.BankName = this.masterdata.RecevierBanks;
        this.terminals = this.masterdata.Terminals;
        this.pjctindicator = this.masterdata.ProjectIndicators;
        this.department = this.masterdata.Departments;
        this.glaccount = this.masterdata.GLCodes;
        this.totallingacc = this.masterdata.DtlTotallingAccCodes;

      },
      errorRturn => this.errorMsg = errorRturn
    );
  }


  createPaymentForm(): void {
    this.paymentForm = this.fb.group({
      receiptdate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required],
      payeename: ['', Validators.required],
      cash: this.fb.group({
        payeename: ['', Validators.required],
        details: ['', Validators.required]
      }),

      cheque: this.fb.group({
        payeebank: [null, Validators.required],
        instrumentdate: [null, Validators.required],
        instrumentnumber: [null, Validators.required],
        payeename: [null, Validators.required],
        details: [null, Validators.required]
      }),

      banktransfer: this.fb.group({
        beneficiarybank: [null, Validators.required],
        beneficiarybankcurrency: [null, Validators.required],
        beneficiaryaccountno: [null, Validators.required],
        iban: [null, Validators.required],
        beneficiaryswiftcode: [null, Validators.required],
        beneficiarysortcode: [null, Validators.required],
        transactiondate: [null, Validators.required],
        transactionnumber: [null, Validators.required],
        correspondentbank: [null, Validators.required],
        correspondentbankaccountno: [null, Validators.required],
        correspondentbankswiftno: [null, Validators.required],
        payeebankname: [null, Validators.required],
        beneficiaryname: [null, Validators.required],
        description: [null, Validators.required]
      }),
      paymentnewrows: this.fb.array([this.createNewPaymentFormGroup()])
    });
  }
  createNewPaymentFormGroup(): FormGroup {
    return this.fb.group({
      description: ['', Validators.required],
      amount: ['', Validators.required],
      reftranid: ['', Validators.required],
      pjctindicator: ['', Validators.required],
      department: ['', Validators.required],
      placeholder: ['', Validators.required],
      reftranslno: ['', Validators.required],
      glaccount: ['4', Validators.required],
      totallingacc: ['', Validators.required]
    });
  }

  addPayment(): void {
    const control = <FormArray>this.paymentForm.controls['paymentnewrows'];
    control.push(this.createNewPaymentFormGroup());

  }

  deleteReceipt(index: number) {
    const control = <FormArray>this.paymentForm.controls['paymentnewrows'];
    control.removeAt(index);
  }

  get cshpayeename() { return this.paymentForm.get('cash.payeename'); }
  get cshdetails() { return this.paymentForm.get('cash.details'); }
  get paymentRows() { return <FormArray>this.paymentForm.get('paymentnewrows'); }

  preview() {

  }

  submitForm() {
   
    this.createPaymentService.createPayment().subscribe(
      dataReturn => this.returnValue = dataReturn,
      errorRturn => this.errorMsg = errorRturn
    );
  }

  goNext() {
    this.level = 2;
  }
  goPrevious() {
    this.level = 1;
  }
  collapseToheader() {
    this.collapsetoheader = !this.collapsetoheader;
  }

}
