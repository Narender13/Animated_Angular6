import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-receipts',
  templateUrl: './receipts.component.html',
  styleUrls: ['./receipts.component.scss']
})
export class ReceiptsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
