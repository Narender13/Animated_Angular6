import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpHeaders, HttpErrorResponse, HttpClient } from '@angular/common/http';
import { catchError, map, shareReplay } from 'rxjs/operators';
import { RSAENDPOINTConstants } from '../../../../core/constants/rsa.api.end.points';
import { handleErrorObservable } from '../../../../shared/utilites/helper';
import { BankTerminal } from '../model/bank.terminal';


@Injectable({ providedIn: 'root' })
export class CreateService {
  private cachedMasterData: Observable<any>;
  private httpheaders = new HttpHeaders(
    {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Headers': 'Content-Type,Origin,content-type',
      'Access-Control-Allow-Methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Origin': '*'
    });

  constructor(private http: HttpClient) { }

  getSearchResults(param): Observable<any> {
    const urlstr = `${RSAENDPOINTConstants.SERVERAPI_SEARCHRESULT}category=${param.category}&loccode=20&searchInput=${param.searchkey}`;
    return this.http.get(RSAENDPOINTConstants.CREATERECEIPT, { headers: this.httpheaders }).pipe(
      map(res => res),
      catchError(handleErrorObservable));
  }
  createReceipt() {
    //dummy
    return this.http.post('api/createreceipt', { headers: this.httpheaders }).pipe(
      map(res => res),
      catchError(handleErrorObservable));
  }

  getMasterData(): Observable<any> {
    return this.http.get<any>(RSAENDPOINTConstants.RECEIPTAPI).pipe(
       map(res => res),
       catchError(handleErrorObservable));
   }
  getAllMasterData() {
    if (!this.cachedMasterData) {
        this.cachedMasterData = this.getMasterData().pipe(shareReplay(1));
    }
    return this.cachedMasterData;
}


}
