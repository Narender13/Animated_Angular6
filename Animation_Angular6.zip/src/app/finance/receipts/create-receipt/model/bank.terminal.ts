
   export interface BankTerminal {
    TransactionType: TransactionType[];
    Departments: Department[];
    RecevierBanks: RecevierBank[];
    LoadPayeeBanks: LoadPayeeBank[];
    Terminals: Terminal[];
    ProjectIndicators: ProjectIndicator[];
}

    export interface TransactionType {
        RefTransactionID: number;
        RefTranArabicDescription?: any;
        RefTranEngDescription: string;
    }

    export interface Department {
        DeparmentCode: number;
        DepADescription: string;
        DepEDescription: string;
    }

    export interface RecevierBank {
        BankCode: number;
        BankArabicDesc?: any;
        BankEngDesc: string;
    }

    export interface LoadPayeeBank {
        BankCode: number;
        BankArabicDesc?: any;
        BankEngDesc: string;
    }

    export interface Terminal {
        UserID: number;
        TerminalArabicDesc: string;
        TerminalEngDesc: string;
        TerminalID: number;
    }

    export interface ProjectIndicator {
        AnalysisCode: number;
        ACArabicDesc: string;
        ACEngDesc: string;
    }

 



