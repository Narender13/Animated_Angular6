import { Component, OnInit } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { CreateService } from './service/create.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BankTerminal } from './model/bank.terminal';
import { Router } from '@angular/router';

@Component({
  selector: 'rsa-create-receipt',
  templateUrl: './create-receipt.component.html',
  styleUrls: ['./create-receipt.component.scss']
})
export class CreateReceiptComponent implements OnInit {
  formBuilder: any;
  title = 'Receipt';
  amount = 0;
  payeedataBankName: any;
  receiverdataBankName: any;
  receiptForm: FormGroup;
  terminals: any;
  level: any = 1;
  collapsetoheader: boolean;
  getbankterminaldetails = {};
  getglcodeanduser: any;
  errorMsg: string;
  searchkey: any;
  id: any;
  isExpaned = false;
  returnValue: any;
  results: any;
  slided;
  currency = 'AED';
  pjctindicator: any;
  department: any;
  placeholder: any;
  glaccount: any;
  totallingacc: any;
  private masterdata: any;

  constructor(public bsModalRef: BsModalRef, private fb: FormBuilder, private createservice: CreateService, private router:Router) { }

  ngOnInit() {
    // this.getBankAndTerminalsOthersC();
    this.getAllMasterData();
    this.createReceiptForm();
    this.getSearchResultsC();


  }

  getSearchResultsC(): void {
    const params = { 'category': 2, 'searchkey': 110 };
    this.createservice.getSearchResults(params).subscribe(
      dataReturn => {
        this.results = dataReturn;

      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  getAllMasterData(): void {
    this.createservice.getAllMasterData().subscribe(
      dataReturn => {
        this.masterdata = dataReturn;
       
        this.payeedataBankName = this.masterdata.LoadPayeeBanks;
        this.receiverdataBankName = this.masterdata.RecevierBanks;
        this.terminals = this.masterdata.Terminals;
        this.pjctindicator = this.masterdata.ProjectIndicators;
        this.department = this.masterdata.Departments;
        this.glaccount = this.masterdata.GLCodes;
        this.totallingacc = this.masterdata.DtlTotallingAccCodes;
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }

  createReceiptForm(): void {
    this.receiptForm = this.fb.group({
      receiptdate: [new DatePipe('en-US').transform(new Date(), 'dd/MM/yyyy'), Validators.required],
      cash: this.fb.group({
        payeename: ['', Validators.required],
        details: ['', Validators.required]
      }),

      cheque: this.fb.group({
        payeebank: [null, Validators.required],
        receiverbank: [null, Validators.required],
        instrumentdate: [null, Validators.required],
        instrumentnumber: [null, Validators.required],
        payeename: [null, Validators.required],
        details: [null, Validators.required]
      }),

      creditcard: this.fb.group({
        cardnumber: [null, Validators.required],
        expirydate: [null, Validators.required],
        approvalcode: [null, Validators.required],
        instrumentdate: [null, Validators.required],
        terminalnumber: [null, Validators.required],
        payeename: [null, Validators.required],
        details: [null, Validators.required]
      }),
      banktransfer: this.fb.group({
        payeebank: [null, Validators.required],
        transactiondate: [null, Validators.required],
        transactionnumber: [null, Validators.required],
        payeename: [null, Validators.required],
        details: [null, Validators.required]
      }),
      others: this.fb.group({
        bankname: [null, Validators.required],
        payeename: [null, Validators.required],
        transactiondate: [null, Validators.required],
        transactionnumber: [null, Validators.required],
        debitduedate: [null, Validators.required],
        debitperiod: [null, Validators.required],
        details: [null, Validators.required]
      }),

      receiptnewrows: this.fb.array([this.createNewReceiptFormGroup()])
    });
  }


  createNewReceiptFormGroup(): FormGroup {
    return this.fb.group({
      description: ['', Validators.required],
      amount: ['', Validators.required],
      reftranid: ['', Validators.required],
      pjctindicator: ['', Validators.required],
      department: ['', Validators.required],
      placeholder: ['', Validators.required],
      reftranslno: ['', Validators.required],
      glaccount: ['4', Validators.required],
      totallingacc: ['', Validators.required]
    });
  }
  addReceipt(): void {
    const control = <FormArray>this.receiptForm.controls['receiptnewrows'];
    control.push(this.createNewReceiptFormGroup());

  }
  deleteReceipt(index: number) {
    const control = <FormArray>this.receiptForm.controls['receiptnewrows'];
    control.removeAt(index);
  }

  get cshpayeename() { return this.receiptForm.get('cash.payeename'); }
  get cshdetails() { return this.receiptForm.get('cash.details'); }
  get receiptRows() { return <FormArray>this.receiptForm.get('receiptnewrows'); }

  submitForm() {
    this.createservice.createReceipt().subscribe(
      dataReturn => this.returnValue = dataReturn,
      errorRturn => this.errorMsg = errorRturn
    );    
  }

  goNext() {
    this.level = 2;
  }
  goPrevious() {
    this.level = 1;
  }

  collapseToheader() {
    this.collapsetoheader = !this.collapsetoheader;
  }



}
