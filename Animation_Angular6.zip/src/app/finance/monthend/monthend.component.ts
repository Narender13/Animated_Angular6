import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-monthend',
  templateUrl: './monthend.component.html',
  styleUrls: ['./monthend.component.scss']
})
export class MonthendComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
