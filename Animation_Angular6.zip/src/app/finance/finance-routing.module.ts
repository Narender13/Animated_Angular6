import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DialogComponent } from './dialog/dialog.component';
import { EntitiesComponent } from './entities/entities.component';
//import { CnpreviewComponent } from './preview/oman/cnpreview/cnpreview.component';
const routes: Routes = [


    {
        path: '',
        children: [
            { path: 'receipt/new', component: DialogComponent },
            { path: 'payment/new', component: DialogComponent },
            {
                path: 'entitie/new', component: EntitiesComponent, data: {
                    breadcrumb: 'Create Entitie'
                }
            },
            { path: 'result', loadChildren: 'src/app/finance/search/search.module#SearchModule' },

        ]
    }
    


];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class FinanceRoutingModule { }
