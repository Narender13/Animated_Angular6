import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';
import { slideInOut } from '../../../../shared/animation/slidein';

@Component({
  selector: 'rsa-create-advocate',
  templateUrl: './create-advocate.component.html',
  styleUrls: ['./create-advocate.component.scss']
})
export class CreateAdvocateComponent implements OnInit {

  advocateForm: FormGroup;
  isArabicField = false;
  address = false;
  address1 = false;
  address2 = false;
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.createEntiteForm();
  }

  createEntiteForm(): void {
    this.advocateForm = this.fb.group({
      advocateinformation: this.fb.group({
        married: ['', Validators.required],
        title: ['', Validators.required],
        name: ['', Validators.required],
        email: ['', Validators.required],
        phonenumber: ['', Validators.required],
        mobilenumber: ['', Validators.required],
        faxnumber: ['', Validators.required],
        branch: ['', Validators.required],
        nationality: ['', Validators.required]
      }),
      address: this.fb.group({
        address: ['', Validators.required],
        address1: ['', Validators.required],
        address2: ['', Validators.required],
        pobox: ['', Validators.required],
        postalcode: ['', Validators.required],
      }),
      addtionalinfo: this.fb.group({
        court: ['', Validators.required],
        specialization: ['', Validators.required],
        cumulativeFee: ['', Validators.required],
        cumulativeCases: ['', Validators.required]
      }),
      status: ['', Validators.required],
      acexective: ['', Validators.required]
    });
  }

  submitForm(): void {
    
  }



}
