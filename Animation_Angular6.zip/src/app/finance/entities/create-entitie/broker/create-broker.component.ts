import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-create-broker',
  templateUrl: './create-broker.component.html',
  styleUrls: ['./create-broker.component.scss']
})
export class CreateBrokerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
