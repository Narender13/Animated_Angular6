import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-create-surveyor',
  templateUrl: './create-surveyor.component.html',
  styleUrls: ['./create-surveyor.component.scss']
})
export class CreateSurveyorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
