import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray, Validators } from '@angular/forms';

import { EntiteCreateService } from '../services/entite-create.service';

@Component({
  selector: 'rsa-entities',
  templateUrl: './entities.component.html',
  styleUrls: ['./entities.component.scss']
})
export class EntitiesComponent implements OnInit {

  entiteType: any;
  selectentitie = 'Agent';
  errorMsg: string;
  entiteMasterdata: any;
  constructor(private fb: FormBuilder, private createEntite: EntiteCreateService) { }


  ngOnInit() {
    this.getEntiteDetails();
  }


  getEntiteDetails(): void {
    this.createEntite.getEntitieType().subscribe((data) => {
      this.entiteMasterdata = data;
      this.entiteType = this.entiteMasterdata.EntiteType;
    },
      errorRturn => this.errorMsg = errorRturn);
  }

}
