import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchResultsComponent } from './search-results/search-results.component';


const routes: Routes = [
    { path: '', redirectTo: '/result', pathMatch: 'full' },
    {
        path: 'result', component: SearchResultsComponent, data: { breadcrumb: 'home' }
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class SearchRoutingModule { }
