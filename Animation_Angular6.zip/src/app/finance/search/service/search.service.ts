import { Injectable } from '@angular/core';
import { HttpParams, HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { map, catchError, tap, shareReplay } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { handleErrorObservable } from 'src/app/shared/utilites/helper';
import { UserProfile } from 'src/app/shared/model/userprofile';

@Injectable()
export class SearchService {

    cacheduserinfo: any;
    //cachedconfigdata:any;
    constructor(private http: HttpClient) { }

    getSearchResults(param): Observable<any> {
      
        const httpHeaders = new HttpHeaders()
            .set('Accept', 'application/json');
        let params = new HttpParams();
        params = params.append('category', param.category);
        params = params.append('inputData', param.inputData);
        params = params.append('categoryitem', param.categoryitem);
       
        const urlstr = `${RSAENDPOINTConstants.SERVERAPI_SEARCHRESULT}`;
       
        //const fakeUrl = `src/assets/json/${param.category}.json`;
        const under_writer_policy_url = `${RSAENDPOINTConstants.SERVER_API_UNDERWRITING_POLICY}`;
        const endorsement_url = `${RSAENDPOINTConstants.SERVER_API_ENDORSEMENT}`;
        const under_writer_quotation_url = `${RSAENDPOINTConstants.SERVER_API_UNDERWRITING_QUOTATION}`;

        const category = param.category;
        let url = '';
        if (category == 1) {
            url = under_writer_policy_url;
            params = params.append('policyNo', param.inputData);
        }
        else if(category == 9){
           url = endorsement_url;
           params = params.append('policyNo', param.inputData);
           params = params.append('endNo', param.inputData);
        }
        else if (category == 10) {
            url = under_writer_quotation_url;
            params = params.append('quoNo', param.inputData);
        } else 
         {   url = urlstr; }   
        
        return this.http.get(url, { params: params, headers: httpHeaders, }).pipe(
            map(res => res),
            catchError(handleErrorObservable));
    }

    getCoulmnHeaderConfig(headerConfig): Observable<any> {
        return this.http.get(headerConfig).pipe(
            map(res => res),
            catchError(handleErrorObservable));
    }
    // getCoulmnHeaderConfig(headerConfig) {
    //     if (!this.cachedconfigdata) {
    //         this.cachedconfigdata = this.getColumnConfig(headerConfig).pipe(shareReplay(1));
    //     }
        
    //     return this.cachedconfigdata;
    // }

    getUserData(): Observable<any> {
        return this.http.get<UserProfile>(RSAENDPOINTConstants.USERPROFILE).pipe(
            map(res => res),
            catchError(handleErrorObservable));
    }
    getUserInfo() {
        if (!this.cacheduserinfo) {
            this.cacheduserinfo = this.getUserData().pipe(shareReplay(1));
        }
        
        return this.cacheduserinfo;
    }

    getFilterData() {
        return {
            'glcode': [{ 'item': 'GL-124' }, { 'item': 'GL-125' }, { 'item': 'GL-126' }],
            'vouchertype': [{ 'item': 'Tax Invoice' }, { 'item': 'Credit Note' },
            { 'item': 'Receipt' }, { 'item': 'Payment' }, { 'item': 'Journal' },
            { 'item': 'Alert Flagged' }],
            'transactiontype': [{ 'item': 'Policy' }, { 'item': 'Endorsement' },
            { 'item': 'Claim' }, { 'item': 'Commission' }, { 'item': 'Excess' },
            { 'item': 'Salvage' }, { 'item': 'Others' }],
            'class': [{ 'item': 'GACC' }, { 'item': 'Fire' }, { 'item': 'Motor' },
            { 'item': 'Marine Cargo' }, { 'item': 'Marine Hull' },
            { 'item': 'Engineering' }, { 'item': 'WC TPL' }]
        }

    }
    getEntityColumnPropertyNames() {
        return ['GLCode',
            'VoucherNo',
            'VoucherType',
            'VoucherDate',
            'TransactionType',
            'Class',
            'TransactionNo',
            'CustomerName',
            'Amount']
    }

}
