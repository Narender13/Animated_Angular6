import { NgModule } from '@angular/core';
import { SharedModule } from '../../shared/shared.module';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SearchRoutingModule } from './search-routing.module';

import { SearchResultsComponent } from './search-results/search-results.component';
import { ReceiptComponent } from './search-results/receipt/receipt.component';
import { EntityComponent } from './search-results/entity/entity.component';
import { ClaimComponent } from './search-results/claim/claim.component';
import { EndorsementnumberComponent } from './search-results/endorsement-number/endorsement-number.component';
import { QuotationnumberComponent } from './search-results/quotation-number/quotation-number.component';
import { PayeenameComponent } from './search-results/payee-name/payee-name.component';
import { ChequeComponent } from './search-results/cheque/cheque.component';
import { PolicyComponent } from './search-results/policy/policy.component';
import { PaymentComponent } from './search-results/payment/payment.component';
import { CreditnoteComponent } from './search-results/credit-note/credit-note.component';
import { JournalComponent } from './search-results/journal/journal.component';
import { TaxComponent } from './search-results/tax/tax.component';

import { SearchService } from './service/search.service';
import { ApprovalCodeComponent } from './search-results/approval-code/approval-code.component';
import { BaseSearchComponent } from './search-results/basesearch/basesearch.component';
import { NoresultsmsgComponent } from './search-results/noresultsmsg/noresultsmsg.component';
import { SettingsComponent } from './search-results/settings/settings.component';


@NgModule({
  imports: [
    SearchRoutingModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule
  ],
  exports: [],
  declarations: [
    SearchResultsComponent,
    ReceiptComponent,
    EntityComponent,
    ClaimComponent,
    EndorsementnumberComponent,
    QuotationnumberComponent,
    PayeenameComponent,
    ChequeComponent,
    PolicyComponent,
    PaymentComponent,
    CreditnoteComponent,
    JournalComponent,
    TaxComponent,
    ApprovalCodeComponent,
    BaseSearchComponent,
    NoresultsmsgComponent,
    SettingsComponent,
  ],
  providers: [
    SearchService
  ],
})
export class SearchModule { }

