import { Component, OnInit, Input } from '@angular/core';
import { BaseSearchComponent } from 'src/app/finance/search/search-results/basesearch/basesearch.component';
import { NoresultsmsgComponent } from 'src/app/finance/search/search-results/noresultsmsg/noresultsmsg.component'

@Component({
  selector: 'rsa-policy',
  templateUrl: './policy.component.html',
  styleUrls: ['./policy.component.scss']
})
export class PolicyComponent extends BaseSearchComponent implements OnInit {
  @Input() category: string;
  @Input('resultdata') resultdata: any = [];
  @Input('policynumber') policynumber: any;
  @Input('userdata') userdata : any;
  showtabledata: number;
  glnumber: string;
  idnumber: number;
  name: string;
  constructor() { super() }

  ngOnInit() {
    this.idnumber = 201838683;
    this.glnumber = '';
    this.name = ' ';
  }

}
