import { Component, OnInit, Input } from '@angular/core';
import { SearchService } from 'src/app/finance/search/service/search.service';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { BaseSearchComponent } from 'src/app/finance/search/search-results/basesearch/basesearch.component';
import { NoresultsmsgComponent } from 'src/app/finance/search/search-results/noresultsmsg/noresultsmsg.component'
@Component({
  selector: 'rsa-journal',
  templateUrl: './journal.component.html',
  styleUrls: ['./journal.component.scss']
})
export class JournalComponent extends BaseSearchComponent implements OnInit {

  errormsg: string;
  cathecoulmnHeaderConfigData: any;
  coulmnHeaderConfigData: any;
  isopen: boolean;
  @Input('resultdata') resultdata: any = [];
  @Input('journalNo') journalNo: any;
  @Input('category') category: any;
  @Input('userdata') userdata : any;
  @Input() settingsdata:any;
	@Input() headerdata:any;

  glnumber: string;
  idnumber = '';
  name = ' ';
  pageSize = 15;
  currentpage: any = 1;
  

  constructor(private searchService: SearchService) { 
    super() 
  }

  ngOnInit() {      
  }
  
  pageChanged(ev) {
    this.currentpage = ev;
  }
  updateTableHeader(data){
    this.headerdata = data;
  }
}
