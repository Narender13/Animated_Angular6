import { Component, OnInit, Input } from '@angular/core';
import { BaseSearchComponent } from 'src/app/finance/search/search-results/basesearch/basesearch.component';
import { NoresultsmsgComponent } from 'src/app/finance/search/search-results/noresultsmsg/noresultsmsg.component'
@Component({
  selector: 'rsa-claim',
  templateUrl: './claim.component.html',
  styleUrls: ['./claim.component.scss']
})
export class ClaimComponent extends BaseSearchComponent implements OnInit {
  @Input('resultdata') resultdata: any = [];
  @Input('claimNo') claimNo: any;
  @Input('category') category: any;
  @Input('userdata') userdata : any;
  name = ' ';
  idnumber = '201838683';
  showtabledata: number;
  constructor() { super() }

  ngOnInit() {
  }

  toggle(index: number): void {
    this.showtabledata = (this.showtabledata !== index) ? index : -1;
  }

}
