import { Component, OnInit, Input } from '@angular/core';
import { SearchService } from 'src/app/finance/search/service/search.service';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';
import { BaseSearchComponent } from 'src/app/finance/search/search-results/basesearch/basesearch.component';
import { NoresultsmsgComponent } from 'src/app/finance/search/search-results/noresultsmsg/noresultsmsg.component'


@Component({
  selector: 'rsa-receipt',
  templateUrl: './receipt.component.html',
  styleUrls: ['./receipt.component.scss'],
})
export class ReceiptComponent extends BaseSearchComponent implements OnInit {
  @Input('resultdata') resultdata: any = [];
  @Input('receiptNo') receiptNo: any;
  @Input('category') category: any;
  @Input('userdata') userdata : any;
  @Input() settingsdata:any;
  @Input() headerdata:any;

   
  glnumber: string;
  idnumber = '';
  name = '';
  pageSize = 15;
  currentpage: any = 1;
  isopen: boolean;
  displayFlag:boolean;

  constructor(private searchService: SearchService) {
     super();     
  }

  ngOnInit() {   
  }
  
  
   pageChanged(ev) {
     this.currentpage = ev;
   }
   updateTableHeader(data){
    this.headerdata = data;
   }
}
