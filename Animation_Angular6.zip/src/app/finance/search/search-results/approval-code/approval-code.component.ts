import { Component, OnInit, Input } from '@angular/core';
import { SearchService } from 'src/app/finance/search/service/search.service';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { BaseSearchComponent } from 'src/app/finance/search/search-results/basesearch/basesearch.component';

@Component({
  selector: 'rsa-approval-code',
  templateUrl: './approval-code.component.html',
  styleUrls: ['./approval-code.component.scss']
})
export class ApprovalCodeComponent extends BaseSearchComponent implements OnInit {

  @Input('resultdata') resultdata: any = [];
  @Input('approvalCode') approvalCode: any;
  @Input('category') category: any;
  @Input('userdata') userdata : any;
  @Input('ReceiptNo') ReceiptNo:any;
  @Input() settingsdata:any;
  @Input() headerdata:any;

  glnumber: string;
  isopen: boolean;
  pageSize = 15;
  currentpage: any = 1;
  idnumber = '';
  name = ' ';
  
  constructor(private searchService: SearchService) {
    super();
  }

  ngOnInit() {
  
  }
 
  pageChanged(ev) {
    this.currentpage = ev;
  }
  
  updateTableHeader(data){
    this.headerdata = data;
   }
}
