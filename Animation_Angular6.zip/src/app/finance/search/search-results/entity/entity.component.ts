import { Component, OnInit, Input } from '@angular/core';
import { NgXDonutChartSlice } from 'ngx-donutchart/ngx-donutchart.type';
import { BaseSearchComponent } from 'src/app/finance/search/search-results/basesearch/basesearch.component';
@Component({
  selector: 'rsa-entity',
  templateUrl: './entity.component.html',
  styleUrls: ['./entity.component.scss']
})
export class EntityComponent extends BaseSearchComponent implements OnInit {
  @Input('resultdata') resultdata: any = [];
  @Input('entityNo') entityNo: any;
  @Input('category') category: any;
  @Input('filtercolumndata') filtercolumndata: any;
  @Input('propertyNames') propertyNames: any;
  @Input('userdata') userdata : any;
  rowopen: boolean = true;
  size: number = 90;
  innerRadius: number = 30;
  slices: NgXDonutChartSlice[] | any[];
  creditlimit: number;
  donutdropdata: any;
  idnumber: number;
  glnumber: string;
  name: string;
  data: any;
  pageSize = 15;
  currentpage: any = 1;
  entitytype: string = "unmatched";
  GLCode;
  default;
  VoucherNo;
  VoucherDate;
  TransactionType;
  CustomerName;
  Amount;
  selectAllFlag;
  Class;
  TransactionNo;
  modifyfilter;
  modifySort;
  filterByDateRange;
  VoucherType;
  tabledata: any = {};
  recordsStart: number = 1;
  recordsEnd: number = 15;
  tabledatasize: number = 70;

  constructor() {
  super()
  }

  ngOnInit() {

    this.idnumber = 201838683;
    this.glnumber = '125,123,126';
    this.name = ' ';
    this.creditlimit = 1000000;
    this.slices = [
      {
        value: 717000,
        color: '#00b5d5',
        message: ''
      },
      {
        value: 65000,
        color: '#ef5ba1',
        message: 'Payment Due(>90 Days)'
      },

    ];
    this.donutdropdata = [
      { item: 'All' },
      { item: 'pl' },
      { item: 'cl' },
      { item: 'sme/spl' }
    ];

    this.data = [
      { 'item': 'Al Batha Group - 125 ', 'group': 3, 'type': 'Broker' },
      { 'item': 'Al Batha Group - 126 ', 'group': 3, 'type': 'Broker' },
      { 'item': 'Al Batha Group - 127 ', 'group': 3, 'type': 'Broker' },
      { 'item': 'Al Batha Reinsureres - 1763', 'type': 'Reinsurerer' },
      { 'item': 'Al Batha - 289 ', 'type': 'Garage' }
    ];
  }
  pageChanged(ev) {
    this.currentpage = ev;
  }
  closePopup(ev) {
    
  }

}
