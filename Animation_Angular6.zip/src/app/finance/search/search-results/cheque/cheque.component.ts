import { Component, OnInit, Input } from '@angular/core';
import { SearchService } from 'src/app/finance/search/service/search.service';
import { CoulmnConfigRecepit } from 'src/app/finance/search/model/coulmn-config-recepit';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { BaseSearchComponent } from 'src/app/finance/search/search-results/basesearch/basesearch.component';

@Component({
  selector: 'rsa-cheque',
  templateUrl: './cheque.component.html',
  styleUrls: ['./cheque.component.scss']
})
export class ChequeComponent extends BaseSearchComponent implements OnInit {

  @Input() category;
  @Input('checknumber') checknumber: any;
  @Input() resultdata;
  @Input('userdata') userdata : any;
  @Input('ReceiptNo') ReceiptNo:any;
  @Input() settingsdata:any;
  @Input() headerdata:any;
  
  glnumber: string;
  idnumber = '';
  name = '';
  pageSize = 15;
  currentpage: any = 1;
  isopen: boolean;

  constructor(private searchService: SearchService) {
    super()
  }
  ngOnInit() {
  
  }
  pageChanged(ev) {
    this.currentpage = ev;
  }
  updateTableHeader(data){
    this.headerdata = data;
   }

}
