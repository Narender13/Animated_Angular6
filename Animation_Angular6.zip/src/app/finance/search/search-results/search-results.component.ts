import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { SearchService } from '../service/search.service';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
@Component({
  selector: 'rsa-search-results',
  templateUrl: './search-results.component.html',
  styleUrls: ['./search-results.component.scss']
})
export class SearchResultsComponent implements OnInit {

  constructor(private searchService: SearchService, private route: ActivatedRoute) { }
  private inputData: string;
  private searchResults: any = [];
  private errorMsg: string;
  private categoryItem: string;
  category: number;
  private filtercolumndata: any;
  private thEntityProperty: any;
  private userdataObj:any;
  private ReceiptNo:any;
  headerdata:any;
  settingsdata:any;
  configurl:string;

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.category = +params['category'];
      this.inputData = params['inputData'];
      this.categoryItem = params['categoryitem'];
      const param = {
        'category': this.category,
        'inputData': this.inputData,
        'categoryitem': this.categoryItem
      };
      this.getSearchResultsData(param);
      this.filtercolumndata = this.searchService.getFilterData();
      this.thEntityProperty = this.searchService.getEntityColumnPropertyNames();

      /*  getting column heads for the table display for result page */

      if( param.category == 12 || param.category == 13 || param.category == 11 ){
        this.configurl = RSAENDPOINTConstants.COULMNHEADERCONFIG;
      }
      else if(param.category == 2){
        this.configurl = RSAENDPOINTConstants.COULMNHEADERCONFIGRECEIPT; 
      }
      else if(param.category == 5 || param.category == 6){
        this.configurl = RSAENDPOINTConstants.COULMNHEADERCONFIGCN;
      }
      else if(param.category == 7){
        this.configurl = RSAENDPOINTConstants.COULMNHEADERCONFIGJV;  
      }
    
      this.getCoulmnHeaderConfig();
      /* end of the logic */
    });
   
    this.getUserData();
  }

  getSearchResultsData(params): void {
    this.searchService.getSearchResults(params).subscribe(
      dataReturn => {
        this.ReceiptNo = (params.category == 12 || params.category == 13) ? dataReturn.ReceiptNo:'';
        this.searchResults=[];
        this.searchResults.push(dataReturn); 
        console.log(this.searchResults[0], 'searchResults');
      },
      errorRturn => this.errorMsg = errorRturn
    );
  }
  getUserData(): void {
    this.searchService.getUserInfo().subscribe((data) => {
      this.userdataObj = data;      
    });
   
  }
  getCoulmnHeaderConfig(): void {
    this.searchService.getCoulmnHeaderConfig(this.configurl).subscribe((data) => {
      this.headerdata = data;
      this.settingsdata = data.map(x => Object.assign({}, x));
     
     });
  }
 

}
