import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { SearchService } from 'src/app/finance/search/service/search.service';

@Component({
  selector: 'rsa-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent implements OnInit {
  isopen: boolean;
  headerData:any;
  errormsg;
  @Input() displayflag:boolean;
  @Output() thdata  = new EventEmitter();
  @Input() settingsdata:any;
  constructor(private searchService: SearchService) { }

  ngOnInit() {
   
  }


  toggleSettings() {
    this.isopen = !this.isopen;
  }
  onSelectionCheckbox(e) {
    if (this.getCount() > 7) {
      e.target.checked = false;
      this.errormsg = '*maximum limit reached';
    }
  }
  changeHandler() {
    if (this.getCount() < 8) {
      this.errormsg = '';
    }
  }
  setTableCoulmn(): void {
     this.headerData = this.settingsdata.map(x => Object.assign({}, x));
     this.isopen = false;
     this.thdata.emit(this.headerData);
   }
 getCount(): number {
    let count = 0;
    this.settingsdata.forEach(item => {
      if (item.checked) {
        count++;
      }
    });
    return count;
  }
  closePopup(): void {
    this.isopen = false;
  }
}
