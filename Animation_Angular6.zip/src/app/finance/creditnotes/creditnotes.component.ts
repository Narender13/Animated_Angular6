import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-creditnotes',
  templateUrl: './creditnotes.component.html',
  styleUrls: ['./creditnotes.component.scss']
})
export class CreditnotesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
