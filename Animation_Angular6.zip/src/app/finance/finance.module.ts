import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchModule } from './search/search.module';
import { SharedModule } from '../shared/shared.module';
import { FinanceRoutingModule } from './finance-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModalModule } from 'ngx-bootstrap/modal';

import { ReceiptsComponent } from './receipts/receipts.component';
import { PaymentsComponent } from './payments/payments.component';
import { GeneralComponent } from './general/general.component';
import { ChequeComponent } from './cheque/cheque.component';
import { JournalsComponent } from './journals/journals.component';
import { DebitnotesComponent } from './debitnotes/debitnotes.component';
import { CreditnotesComponent } from './creditnotes/creditnotes.component';
import { ReportsComponent } from './reports/reports.component';
import { EntitiesComponent } from './entities/entities.component';
import { MonthendComponent } from './monthend/monthend.component';
import { DialogComponent } from './dialog/dialog.component';
import { CreateReceiptComponent } from './receipts/create-receipt/create-receipt.component';
import { CreateAgentComponent } from './entities/create-entitie/agent/create-agent.component';
import { CreateAdvocateComponent } from './entities/create-entitie/advocate/create-advocate.component';
import { CreateBrokerComponent } from './entities/create-entitie/broker/create-broker.component';
import { CreateCustomerComponent } from './entities/create-entitie/customer/create-customer.component';
import { CreateCompanyComponent } from './entities/create-entitie/company/create-company.component';
import { CreatePoliceStationComponent } from './entities/create-entitie/police-station/create-police-station.component';
import { CreateRecoveryAgentComponent } from './entities/create-entitie/recovery-agent/create-recovery-agent.component';
import { CreateSurveyorComponent } from './entities/create-entitie/surveyor/create-surveyor.component';
import { CreateRepairerComponent } from './entities/create-entitie/repairer/create-repairer.component';
import { CreatePaymentComponent } from './payments/create-payment/create-payment.component';

/* preview component */
// import { ReceiptpreviewComponent } from './preview/oman/receiptpreview/receiptpreview.component';
// import { TaxinvoicepreviewComponent } from './preview/oman/taxinvoicepreview/taxinvoicepreview.component';
// import { PaymentpreviewComponent } from './preview/oman/paymentpreview/paymentpreview.component';
// import { ClaimpreviewComponent } from './preview/oman/claimpreview/claimpreview.component';
// import { JvpreviewComponent } from './preview/oman/jvpreview/jvpreview.component';
// import { CnpreviewComponent } from './preview/oman/cnpreview/cnpreview.component';
// import { ReceiptcancelledpreviewComponent } from './preview/oman/receiptcancelledpreview/receiptcancelledpreview.component';

/* end */

@NgModule({
  imports: [
    CommonModule,
    SearchModule,
    SharedModule,
    FinanceRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    //SharedCreateEntitieModule,
    ModalModule.forRoot()
  ],
  declarations: [
    ReceiptsComponent,
    PaymentsComponent,
    GeneralComponent,
    ChequeComponent,
    JournalsComponent,
    DebitnotesComponent,
    CreditnotesComponent,
    ReportsComponent,
    EntitiesComponent,
    MonthendComponent,
    DialogComponent,
    CreateReceiptComponent,
    CreateAgentComponent, 
    CreateAdvocateComponent, 
    CreateBrokerComponent,
    CreateCustomerComponent, 
    CreateCompanyComponent,
    CreatePoliceStationComponent, 
    CreateRecoveryAgentComponent, 
    CreateSurveyorComponent, 
    CreateRepairerComponent, 
    CreatePaymentComponent, 
   // ReceiptpreviewComponent, TaxinvoicepreviewComponent, PaymentpreviewComponent, ClaimpreviewComponent, JvpreviewComponent, CnpreviewComponent, ReceiptcancelledpreviewComponent
  ],
  entryComponents: [CreateReceiptComponent, CreatePaymentComponent],
})
export class FinanceModule { }
