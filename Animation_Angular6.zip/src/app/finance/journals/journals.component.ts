import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-journals',
  templateUrl: './journals.component.html',
  styleUrls: ['./journals.component.scss']
})
export class JournalsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
