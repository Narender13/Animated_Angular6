import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'rsa-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss']
})
export class ReportsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
