import { Component, OnInit, Input } from '@angular/core';
import { BsModalService } from 'ngx-bootstrap/modal';
import { BsModalRef } from 'ngx-bootstrap/modal/bs-modal-ref.service';
import { CreateReceiptComponent } from '../receipts/create-receipt/create-receipt.component';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { CreatePaymentComponent } from '../payments/create-payment/create-payment.component';

@Component({
  selector: 'rsa-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss']
})
export class DialogComponent implements OnInit {

  private bsModalRef: BsModalRef;
  private errorMsg: string;
  private configdialog: any;

  constructor(private modalService: BsModalService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.route.queryParams.subscribe(
      param => this.configdialog = param,
      err => this.errorMsg = err
    );
    this.openModal();
    this.router.navigate(['/home']);
  }

  openModal() {
    switch (this.configdialog.dialogname) {
      case 'Receipts':
        this.bsModalRef = this.modalService.show(CreateReceiptComponent,
          Object.assign({}, this.configdialog, { class: 'create-modal-dailog' }));
        break;
      case 'Payments':
        this.bsModalRef = this.modalService.show(CreatePaymentComponent,
          Object.assign({}, this.configdialog, { class: 'create-modal-dailog' }));
        break;
    }
  }
}


