export const RSAMSGConstants = {
 NORESULTMSG:"No Records Found."
}