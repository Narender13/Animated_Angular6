import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';

import { Page404Component } from './page404/page404.component';
import { httpInterceptorProviders } from 'src/app/core/interceptor/index';
import { RSAENDPOINTConstants } from 'src/app/core/constants/rsa.api.end.points';
import { RSAMSGConstants } from 'src/app/core/constants/rsa.msg.constants';

@NgModule({
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    CommonModule,
    HttpModule,
    HttpClientModule,
  ],
  declarations: [
    Page404Component,
  ],
  providers: [
    httpInterceptorProviders,
  ],
  exports: [
    Page404Component,
  ]

})
export class CoreModule { }
