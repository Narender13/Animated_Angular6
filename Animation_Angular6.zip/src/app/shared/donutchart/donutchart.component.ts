import { Component, OnInit, Input } from '@angular/core';
import {NgXDonutChartSlice} from 'ngx-donutchart/ngx-donutchart.type';

@Component({
  selector: 'rsa-donutchart',
  templateUrl: './donutchart.component.html',
  styleUrls: ['./donutchart.component.scss']
})
export class DonutchartComponent implements OnInit {
  @Input() size: number = 120;
  @Input() innerRadius: number = 40;
  @Input() slices: NgXDonutChartSlice[] | any[];
  @Input() creditlimit: number;
  @Input() donutdropdata: any;
  
  constructor() { }

  ngOnInit() {    
   
  }
  hoverChart(event){
    console.log(event);
  }

}
