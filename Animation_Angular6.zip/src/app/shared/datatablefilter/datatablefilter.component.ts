import { Component, OnInit, Output, Input, EventEmitter, Renderer2, AfterViewInit } from '@angular/core';

import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';


@Component({
  selector: 'app-datatablefilter',
  templateUrl: './datatablefilter.component.html',
  styleUrls: ['./datatablefilter.component.scss']
})
export class DatatablefilterComponent implements OnInit {
  @Output() filterChange: EventEmitter<any> = new EventEmitter<any>();
  @Output() sortChange: EventEmitter<any> = new EventEmitter<any>();
  @Output() daterangevalue: EventEmitter<any> = new EventEmitter<any>();

  @Input() sortColumnName = ''
  @Input() dataforFilter: any;
  @Input() filtertype: string;
  @Input() boxwidth: string;
  @Input() searchFilterFlag: boolean;

  private daterangeval: Date;
  private filter: any = '';
  private isOpen = false;
  private open = false;

  private eventDelay: Subject<any> = new Subject<any>();

  constructor(private renderer: Renderer2) {

  }

  ngOnInit() {
        this.eventDelay.pipe(
      debounceTime(250),
      distinctUntilChanged()
    ).subscribe((val) => this.filterChange.emit(val));


  }

  filterChanged() {

    let a = this.sortColumnName;
    let emitVal = {};
    let arrayEmit = [];
    emitVal[a] = this.filter;
    arrayEmit.push(emitVal);
    this.eventDelay.next(arrayEmit);
  }

  sortData(paramSortFlag: boolean) {
    this.sortChange.emit({ 'col': this.sortColumnName, 'flag': paramSortFlag });
  }
  toggleDatePicker() {

    this.isOpen = !this.isOpen;

  }
  hideDatePicker() {
    this.isOpen = false;
    if (this.daterangeval !== null && this.daterangeval !== undefined)
      this.daterangevalue.emit({ "daterangeval": this.daterangeval, "sortColumnName": this.sortColumnName });

  }
  openFilter(event) {
    this.open = !this.open;
  }
  changeUniqueFilter(ev) {
    if (ev.length > 0) this.filterChange.emit(ev); else this.filterChange.emit("");
  }

}
