import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';

export const handleErrorObservable = function (error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
        console.error('Error sending a request", error.error.message');
    } else {
        console.log('error', error);
        console.error(
            `Backend returned code ${error.status}, ` +
            `body was: ${error.error}`);
    }
    return throwError(
        'Something bad happened; please try again later.');
};


