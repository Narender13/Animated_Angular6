import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';

export class UtilityClass {
    constructor(private router: Router, private activateRoute: ActivatedRoute) {
        const a = this.getRoute();
        
    }

    getRoute(): Observable<boolean> {
        return this.router.events.pipe(
            map((event) => {
                if (event instanceof NavigationEnd) {
                  
                    return this.router.url === '/home' ? true : false;
                }
            }));
    }
}
