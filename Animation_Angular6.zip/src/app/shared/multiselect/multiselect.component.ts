import { Component, OnInit, Renderer2, ElementRef, Input, Output, EventEmitter } from '@angular/core';
import { Activity } from '../../home/modal/activity';
@Component({
  selector: 'rsa-multiselect',
  templateUrl: './multiselect.component.html',
  styleUrls: ['./multiselect.component.scss']
})
export class MultiselectComponent implements OnInit {
  @Input() data: Activity[];
  private items;
  errormsg: string;
  constructor(private rendere2: Renderer2, private elementRef: ElementRef) { }
  open: boolean;
  private cntFlag:boolean=false;
  count:number;
  ngOnInit() {

  }

  toggelMenu(obj) {
    this.open = !this.open;
    this.errormsg = '';
  }
  selectionCheckbox(e,id) {
    this.count = 0;
    
    this.data.forEach(item => {
      if (item.id === id && e.target.checked) {
           item.checked = true;
         }
      else if (item.id === id && !e.target.checked) {
        item.checked = false;
      }
      if (item.checked) {
        this.count++;      
      }
      if(this.count >= 5){
        this.errormsg = '*maximum limit reached';
        e.target.checked = false;
         }
      else
      {
      this.errormsg ='';
      this.cntFlag = false;
     }
    });
   
  }

  closePopup(val: boolean) {
    this.open = false;
    this.errormsg = '';
  }

}
