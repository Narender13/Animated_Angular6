import { Directive, ElementRef, Output, EventEmitter, HostListener } from '@angular/core';

@Directive({
  selector: '[rsa-nav-click]'
})
export class NavclickDirective {

  @Output() public clickOutsidenav = new EventEmitter();
  
  constructor(private elementRef : ElementRef) { }

  @HostListener('document:click', ['$event.target']) public onClick(targetElement) {
    
    let isClickedInside:boolean = this.elementRef.nativeElement.contains(targetElement);
    
    if (!isClickedInside && (targetElement.className.indexOf('open-nav-btn')==-1)) {
       this.clickOutsidenav.emit(true);
    }
  }

}
