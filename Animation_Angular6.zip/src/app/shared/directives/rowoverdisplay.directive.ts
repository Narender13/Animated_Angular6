import { Directive, HostListener, Renderer2, ElementRef } from '@angular/core';

@Directive({
  selector: '[rsaRowoverdisplay]'
})
export class RowoverdisplayDirective {

  constructor(private renderer : Renderer2, private eleRef: ElementRef) { }
  @HostListener('click', ['$event']) public onClick(ev) {
    
    if(ev.target.className.indexOf('fa-angle-down')>-1){
      this.renderer.removeClass(this.eleRef.nativeElement.nextElementSibling,'row--hide');
    }
    else if(ev.target.className.indexOf('fa-angle-up')>-1){
      this.renderer.addClass(ev.currentTarget,'row--hide');
    }
   
  }
  @HostListener('mouseenter', ['$event']) public onMouseEnter(ev) {
    this.renderer.addClass(ev.currentTarget,'enter');
 
  }
  @HostListener('mouseleave', ['$event']) public onMouseLeave(ev) {
    this.renderer.removeClass(ev.currentTarget,'enter');
  }
}
