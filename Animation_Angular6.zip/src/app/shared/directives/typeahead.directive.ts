import { Directive, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[rsa-typeahead-animate]'
})
export class TypeaheadDirective {

  constructor() { }
  @HostBinding('class.typeahead-open') slided: boolean =false;
  @HostListener('click') focusedin() {
    this.slided = true;
    }
  @HostListener('focusout') focusedout() {
    setTimeout( () => {this.slided = false;},200);
   }
}
