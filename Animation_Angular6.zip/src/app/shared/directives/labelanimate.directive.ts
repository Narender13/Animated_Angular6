import { Directive, HostBinding, HostListener } from '@angular/core';

@Directive({
  selector: '[rsa-label-animate]'
})
export class LabelanimateDirective {

  constructor() { }
  
  @HostBinding('class.animated') animated: string ="animated";

  @HostListener('focusin') focused() {
    this.animated = '';
   
  }
}
