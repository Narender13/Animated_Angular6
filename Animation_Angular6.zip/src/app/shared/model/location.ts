export interface Area {
    id: number;
    item: string;
    divider: boolean;
}
