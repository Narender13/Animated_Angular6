export class UserProfile {
    firstname: string;
    lastname: string;
    profileurl: string;
    bannerurl: string;
    logourl: string;
    location:Array<City>;
}
export class City {
    id:number;
    item:string;
}
