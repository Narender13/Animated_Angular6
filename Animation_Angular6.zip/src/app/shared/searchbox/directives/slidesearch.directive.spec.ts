import { SlidesearchDirective } from './slidesearch.directive';

describe('SlidesearchDirective', () => {
  it('should create an instance', () => {
    const directive = new SlidesearchDirective();
    expect(directive).toBeTruthy();
  });
});
