import { Component, OnInit, Renderer2, ElementRef, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HomeService } from '../../home/services/home.service';
import { CategoryType } from 'src/app/finance/search/model/category';

@Component({
  selector: 'rsa-searchbox',
  templateUrl: './searchbox.component.html',
  styleUrls: ['./searchbox.component.scss']
})
export class SearchboxComponent implements OnInit {
  // private searchForm: FormGroup;
  categories: any;
  private searchdata: any;
  private searchval = '';
  category: any;
  categoryItem: string;
  private invalidsearch: boolean;

  @Output() searchvalemit = new EventEmitter<string>();
  constructor(private fb: FormBuilder, private renderer: Renderer2, private router: Router, private homeservice: HomeService) { }

  ngOnInit() {
    this.getCategorydataData();
    this.getEntitySearchListData();
  }

  emitSearchValue() {
    this.searchvalemit.emit(this.searchval);
  }

  setSelectedCategory(category: CategoryType) {
    this.category = category.id;
    this.categoryItem = category.item;
    this.searchval = '';
  }

  search() {
    this.invalidsearch = (this.category !== undefined && this.category > 0) &&
      (this.searchval !== undefined && this.searchval !== '' && this.searchval.length > 0);
    if (this.invalidsearch) {
      this.router.navigate(['home/search/result'], {
        queryParams: {
          'inputData': this.searchval,
          'category': this.category,
          'categoryitem': this.categoryItem
        }
      });
    }
  }

  getCategorydataData(): void {
    this.homeservice.getCategoryData().subscribe((dropDowndata) => {
      this.categories = dropDowndata;
    });
  }

  getEntitySearchListData(): void {
    this.homeservice.getEntityData().subscribe((searchlistdata) => {
      this.searchdata = searchlistdata;
    });
  }
}
