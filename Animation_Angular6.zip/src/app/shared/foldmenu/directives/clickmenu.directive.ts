import { Directive, ElementRef, Renderer2, Output, EventEmitter, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[rsamenuclick]'
})
export class ClickmenuDirective {
  @Input() animationState: string;
  @Input() selectedValue: string = "Category";

  constructor(private elementRef: ElementRef, private renderer2: Renderer2) { }

  @HostListener('click', ['$event']) public onClick(event) {
    let currentTarget: string = event.currentTarget.className;

    switch (currentTarget) {
      case "dropdown":

        break;
      case "dropbtn":
        this.openMenu(event.currentTarget);
        break;
      case "viewall":
        this.unfoldMenu(event.currentTarget);

        break;
      case "viewless":
        this.foldMenu(event.currentTarget);
        break;

    }
  }
  openMenu(objdropdown: string) {
    this.animationState = this.animationState === 'out' ? 'in' : 'out';
    this.renderer2.removeClass(objdropdown, 'viewless');
    this.renderer2.removeClass(objdropdown, 'viewall');
  }
  unfoldMenu(sub) {
    this.renderer2.addClass(sub, 'viewall');
    this.renderer2.removeClass(sub, 'viewless');
  }
  foldMenu(sub) {
    this.renderer2.addClass(sub, 'viewless');
    this.renderer2.removeClass(sub, 'viewall');
  }

  handleDropdownEvent(objdropdown, ev, valueTxt) {

    if (ev.target.tagName === 'A') {
      if (ev.target.className.indexOf('viewall') > -1)
        this.unfoldMenu(objdropdown);
      else if (ev.target.className.indexOf('viewless') > -1)
        this.foldMenu(objdropdown);
      else {
        this.selectedValue = ev.target.text;
        this.animationState = 'out';

      }
    }
  }
}
