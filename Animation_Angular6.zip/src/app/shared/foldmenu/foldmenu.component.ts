import { Component, OnInit, Renderer2, Input, Output, EventEmitter } from '@angular/core';
import { Slide } from '../animation/slide';
@Component({
  selector: 'rsa-foldmenu',
  templateUrl: './foldmenu.component.html',
  styleUrls: ['./foldmenu.component.scss'],
  animations: [Slide]
})
export class FoldmenuComponent implements OnInit {

  @Input() data: any;
  @Output() selectedvalemit = new EventEmitter<any>();
  animationState = 'out';
  selectedValue = 'Category';

  constructor(private renderer2: Renderer2) { }

  ngOnInit() {

  }
  openMenu(objdropdown) {
    this.animationState = this.animationState === 'out' ? 'in' : 'out';
    this.renderer2.removeClass(objdropdown, 'viewless');
    this.renderer2.removeClass(objdropdown, 'viewall');
  }
  unfoldMenu(sub) {
    this.renderer2.addClass(sub, 'viewall');
    this.renderer2.removeClass(sub, 'viewless');
  }
  foldMenu(sub) {
    this.renderer2.addClass(sub, 'viewless');
    this.renderer2.removeClass(sub, 'viewall');
  }

  handleDropdownEvent(objdropdown, ev) {
    if (ev.target.tagName === 'A') {
      if (ev.target.className.indexOf('viewall') > -1) {
        this.unfoldMenu(objdropdown);
      } else if (ev.target.className.indexOf('viewless') > -1) {
        this.foldMenu(objdropdown);
      } else {
       
        this.selectedValue = ev.target.text;
        this.selectedvalemit.emit({ id: ev.target.id, item: ev.target.text });
        this.animationState = 'out';
      }
    }
  }

  closePopup() {
    this.animationState = 'out';
  }
}
