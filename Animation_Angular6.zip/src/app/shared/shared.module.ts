
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { TypeaheadModule } from 'ngx-bootstrap/typeahead';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgxPaginationModule } from 'ngx-pagination';
import { NgXDonutChartModule } from 'ngx-donutchart';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ModalModule } from 'ngx-bootstrap';

import { SearchService } from '../finance/search/service/search.service';
import { BsModalService } from 'ngx-bootstrap/modal';

import { HeaderComponent } from './header/header.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { FooterComponent } from './footer/footer.component';
import { FoldmenuComponent } from './foldmenu/foldmenu.component';
import { MultiselectComponent } from './multiselect/multiselect.component';
import { DropdownComponent } from './dropdown/dropdown.component';
import { DonutchartComponent } from './donutchart/donutchart.component';
import { DatatablefilterComponent } from './datatablefilter/datatablefilter.component';
import { IdcardComponent } from './idcard/idcard.component';
import { SearchboxComponent } from './searchbox/searchbox.component';
import { BreadcrumbComponent } from './breadcrumb/breadcrumb.component';
import { ConfirmationDialogComponent } from 'src/app/shared/custom-model/custom-model.component';
import { AlertComponent } from 'src/app/shared/alert-rsa/alert.component';

import { RowoverdisplayDirective } from './directives/rowoverdisplay.directive';
import { FilterCheckboxDelegationDirective } from './directives/filter-checkbox-delegation.directive';
import { ClickoutsideDirective } from './directives/clickoutside.directive';
import { LabelanimateDirective } from './directives/labelanimate.directive';
import { TypeaheadDirective } from './directives/typeahead.directive';
import { SlidesearchDirective } from './searchbox/directives/slidesearch.directive';
import { ClickmenuDirective } from './foldmenu/directives/clickmenu.directive';
import { NavclickDirective } from './directives/navclick.directive';


import { DateFormatPipe } from 'src/app/shared/pipes/dateFormat-pipe';


@NgModule({
    declarations: [
        /* components */
        HeaderComponent,
        SidebarComponent,
        FooterComponent,
        FoldmenuComponent,
        MultiselectComponent,
        DropdownComponent,
        DonutchartComponent,
        DatatablefilterComponent,
        IdcardComponent,
        SearchboxComponent,
        BreadcrumbComponent,
        ConfirmationDialogComponent,
        AlertComponent,
        /* directives */
        RowoverdisplayDirective,
        ClickoutsideDirective,
        FilterCheckboxDelegationDirective,
        LabelanimateDirective,
        TypeaheadDirective,
        SlidesearchDirective,
        ClickmenuDirective,
        NavclickDirective,
        /* Pipes */
        DateFormatPipe

    ],
    imports: [
        CommonModule,
        RouterModule,
        BsDatepickerModule.forRoot(),
        TabsModule.forRoot(),
        TypeaheadModule.forRoot(),
        ModalModule.forRoot(),
        NgxSpinnerModule,
        NgxPaginationModule,
        NgXDonutChartModule,
        FormsModule,
        ReactiveFormsModule,

    ],
    providers: [SearchService, BsModalService],
    exports: [
        /* components */
        HeaderComponent,
        SidebarComponent,
        FooterComponent,
        FoldmenuComponent,
        MultiselectComponent,
        DonutchartComponent,
        DatatablefilterComponent,
        IdcardComponent,
        DropdownComponent,
        BreadcrumbComponent,
        ConfirmationDialogComponent,
        AlertComponent,
        /* directives */
        RowoverdisplayDirective,
        FilterCheckboxDelegationDirective,
        ClickoutsideDirective,
        LabelanimateDirective,
        TypeaheadDirective,
        NavclickDirective,
        /* Pipes */
        DateFormatPipe,
        /* modules */
        TypeaheadModule,
        NgxSpinnerModule,
        NgxPaginationModule,
        NgXDonutChartModule,
        BsDatepickerModule,
        TabsModule
    ]
})
export class SharedModule { }
