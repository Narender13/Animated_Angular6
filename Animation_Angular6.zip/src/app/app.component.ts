import { Component, AfterViewInit, ChangeDetectorRef, OnInit } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute, RouteConfigLoadStart, RouteConfigLoadEnd } from '@angular/router';
import { LoaderService } from './core/loader/loader-service';
import { HomeService } from './home/services/home.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  isHome: boolean;
  isLoading: boolean;
  countrycode: any;
  errorMsg: string;
  bannerurl: string;
  profileurl: string;

  constructor(private router: Router, private homeservice: HomeService, private loaderService: LoaderService,
    private cdr: ChangeDetectorRef
  ) {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this.isHome = this.router.url === '/home' ? true : false;
      }
      if (event instanceof RouteConfigLoadStart) {
        this.isLoading = true;
      } else if (event instanceof RouteConfigLoadEnd) {
        this.isLoading = false;
      }
    });
    this.loaderService.isLoading().subscribe(loading => {
      this.isLoading = loading;
    });

  }
  ngOnInit() {
    this.getUserData();
  }
  getUserData(): void {
    this.homeservice.getUserInfo().subscribe((data) => {
      this.bannerurl = data.bannerurl;
    });

  }

}

